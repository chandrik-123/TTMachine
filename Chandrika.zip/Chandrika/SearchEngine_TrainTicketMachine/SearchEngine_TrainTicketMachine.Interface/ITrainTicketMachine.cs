﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainTicketMachine_Entites;

namespace SearchEngine_TrainTicketMachine.Interface
{
    public interface ITrainTicketMachine
    {
        string[] GetAllStations();
        List<searchstation> GetAllStartedWithName(string input);

        char GetNextCharacter(string reference, string input);
    }
}
