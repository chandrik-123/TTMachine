﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SearchEngine_TrainTicketMachine.Respositary;
using TrainTicketMachine_Entites;

namespace TrainTicketMachine.UnitTestCase
{
    [TestClass]
    public class UnitTest1
    {
       
        [TestMethod]
        public void RunATest1()
        {
            TestMethod1("DART");
        }

       [TestMethod]
        public void RunATest2()
        {
            TestMethod2("LIVERPOOL");
        }

        [TestMethod]
        public void RunATest3()
        { 
            TestMethod3("KINGS CROSS");
        }
         public void TestMethod1(string input)
        {
            SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine trainTicketMachine = new SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine();
            StationsArray.stations = new string[] { "DARTFORD", "DARTMOUTH", "DERBY" };

            searchstationResultSet set = new searchstationResultSet(trainTicketMachine.GetAllStartedWithName(input));
            Assert.IsTrue(set.allNextCharacters.Any(c => c == 'F'));
            Assert.IsTrue(set.allNextCharacters.Any(c => c == 'M'));
            Assert.IsTrue(set.stations.Any(s => s == "DARTFORD"));
            Assert.IsTrue(set.stations.Any(s => s == "DARTMOUTH"));
        }

       
        public void TestMethod2(string input)
        {
            SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine stationRep = new SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine();
            StationsArray.stations = new string[] { "LIVERPOOL", "LIVERPOOL LIME STREET", "PADDINGTON" };

            searchstationResultSet set = new searchstationResultSet(stationRep.GetAllStartedWithName(input));
            Assert.IsTrue(set.allNextCharacters.Any(r => r == ' '));
            Assert.IsTrue(set.stations.Any(r => r == "LIVERPOOL"));
            Assert.IsTrue(set.stations.Any(r => r == "LIVERPOOL LIME STREET"));
        }

       
        public void TestMethod3(string input)
        {
            SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine stationRep = new SearchEngine_TrainTicketMachine.Respositary.TrainTicketMachine();
            StationsArray.stations = new string[] { "EUSTON", "LONDON BRIDGE", "VICTORIA" };

            searchstationResultSet set = new searchstationResultSet(stationRep.GetAllStartedWithName(input));
            Assert.IsTrue(set.allNextCharacters.Count == 0);
            Assert.IsTrue(set.stations.Count == 0);
        }
    }
}
