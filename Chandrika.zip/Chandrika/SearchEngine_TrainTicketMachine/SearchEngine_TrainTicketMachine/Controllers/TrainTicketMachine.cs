﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SearchEngine_TrainTicketMachine.Interface;
using TrainTicketMachine_Entites;

namespace SearchEngine_TrainTicketMachine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainTicketMachine : ControllerBase
    {

        private readonly ILogger<TrainTicketMachine> _logger;
        private readonly ITrainTicketMachine _trainTicketMachine;
        public TrainTicketMachine(ILogger<TrainTicketMachine> logger, ITrainTicketMachine trainTicketMachine)
        {
            _logger = logger;
            _trainTicketMachine = trainTicketMachine;
        }
        [HttpGet]
        [Route("Get")]
        public string Get(string input)

        {
            string[] arraystations = { "DARTFORD", "DARTMOUTH", "TOWER HILL", "DERBY", "LIVERPOOL", "LIVERPOOL LIME STREET", "PADDINGTON", "EUSTON", "LONDON BRIDGE", "VICTORIA" };

            List<searchstation> searchResultList = new List<searchstation>();


            for (int i = 0; i < arraystations.Length; i++)
            {
                if (arraystations[i].StartsWith(input))
                {
                    searchResultList.Add(new searchstation
                    {
                        station = arraystations[i],
                        nextCharacter = GetNextCharacter(arraystations[i], input)
                    });
                }
            }
            string stations = "1.The stations ";


            string characters = "2.The characters ";

            if (searchResultList.Count == 0)
            {
                stations = "1.no next characters ";


                characters = "2.no stations";
            }
            else
            {
                foreach (var item in searchResultList)
                {
                    stations += item.station + " ";
                    characters += item.nextCharacter + " ";


                }
            }
            return stations + characters;



        }
        public char GetNextCharacter(string reference, string input)
        {
            try
            {

                return reference.Replace(input, String.Empty).ToCharArray().ToList()[0];
            }

            catch
            {
                return (char)0;
            }
        }
    }
}
